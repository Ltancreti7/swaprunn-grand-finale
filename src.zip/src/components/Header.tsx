import { AppHeader } from './AppHeader';

export function Header() {
  return <AppHeader />;
}
