import React from 'react'
import { createRoot } from 'react-dom/client'
import { RouterProvider, createBrowserRouter } from 'react-router-dom'
import App from './ui/App'
import Jobs from './ui/Jobs'
import History from './ui/History'
import Drivers from './ui/Drivers'
import Billing from './ui/Billing'
import DriverApp from './ui/DriverApp'
import Track from './ui/Track'

const router = createBrowserRouter([
  { path: '/', element: <App /> },
  { path: '/jobs', element: <Jobs /> },
  { path: '/history', element: <History /> },
  { path: '/drivers', element: <Drivers /> },
  { path: '/billing', element: <Billing /> },
  { path: '/driver', element: <DriverApp /> },
  { path: '/track/:token', element: <Track /> },
])

createRoot(document.getElementById('root')!).render(<RouterProvider router={router} />)
